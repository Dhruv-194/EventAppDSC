package com.example.minervamun;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class ComiteesScreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
CardView Commitee1;
DrawerLayout drawerLayout;
NavigationView navigationView;
Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comitees_screen);
        drawerLayout = findViewById(R.id.drawerlayout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);




        Commitee1 = findViewById(R.id.Commitee1);
        Commitee1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            /*   Intent intent = new Intent(ComiteesScreen.this, Commitee1.class);
                startActivity(intent);*/
            /*DialogCommitee1 dialogCommitee1 = new DialogCommitee1();
               dialogCommitee1.show(getSupportFragmentManager(), "dialog commitee1");*/

             final AlertDialog.Builder alert = new AlertDialog.Builder(ComiteesScreen.this);
               View view =  getLayoutInflater().inflate(R.layout.layout_dialog, null);

               final  EditText edit_pin = view.findViewById(R.id.edit_pin);
               alert.setView(view);

               final AlertDialog alertDialog = alert.create();


               alert.setTitle("Enter Commitee")
                       .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {

                           }
                       })
                       .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               String pin = edit_pin.getText().toString();
                               if (pin.equals("mun01")){
                                   Intent intent = new Intent(ComiteesScreen.this, Commitee1.class);
                                   startActivity(intent);
                               }
                               else {
                                   Toast.makeText(ComiteesScreen.this, "Please enter correct PIN", Toast.LENGTH_SHORT).show();
                               }
                           }
                       });
               alert.show();

            }

        });

    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.Teams:
                Intent intent = new Intent(ComiteesScreen.this, MeetTheTeam.class);
                startActivity(intent);
                break;
            case R.id.Testimonial:
                Intent intent1 = new Intent(ComiteesScreen.this, Testomnials.class);
                startActivity(intent1);
                break;
            case R.id.Quiz:
                Toast.makeText(ComiteesScreen.this, "A Quiz/Game Might be played", Toast.LENGTH_SHORT).show();
                break;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}