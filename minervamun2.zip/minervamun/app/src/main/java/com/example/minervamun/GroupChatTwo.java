package com.example.minervamun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GroupChatTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat_two);
    }
}