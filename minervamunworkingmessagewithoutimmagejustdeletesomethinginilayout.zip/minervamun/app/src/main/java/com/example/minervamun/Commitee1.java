package com.example.minervamun;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Commitee1 extends AppCompatActivity {

    Button commitee1chat;
    Button commitee1pdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commitee1);

        commitee1chat = findViewById(R.id.groupchatone);
        commitee1pdf = findViewById(R.id.pdfguide1);

        commitee1chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Commitee1.this, GroupChatOne.class);
                startActivity(intent);
            }
        });

        commitee1pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Commitee1.this, PdfGuide1.class);
                startActivity(intent);
            }
        });

    }
}