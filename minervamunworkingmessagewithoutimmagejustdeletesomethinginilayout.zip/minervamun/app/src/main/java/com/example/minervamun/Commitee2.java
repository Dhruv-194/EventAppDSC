package com.example.minervamun;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Commitee2 extends AppCompatActivity {

    Button commitee2chat;
    Button commitee2pdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commitee2);

        commitee2chat = findViewById(R.id.groupchattwo);
        commitee2pdf = findViewById(R.id.pdfguide2);

        commitee2chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Commitee2.this, GroupChatTwo.class);
                startActivity(intent);
            }
        });

        commitee2pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Commitee2.this, PdfGuide1.class);
                startActivity(intent);
            }
        });

    }
}