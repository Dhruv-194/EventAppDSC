package com.example.minervamun.Modals;

public class AllMethods {

    public static String name = "";
}
